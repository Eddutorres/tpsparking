
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Editar Cantidad de Estacionamientos
            Habilitados</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>Sector</th>
                        <th>Editar</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>VARAS</td>
                        <td><a href="#" class="btn btn-warning btn-icon-split btn-sm"
                                data-toggle="modal" data-target="#EditModal">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>

                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>PRAT</td>
                        <td><a href="#" class="btn btn-warning btn-icon-split btn-sm"
                                data-toggle="modal" data-target="#EditModal">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>

                            </a>
                        </td>

                    </tr>
                    <tr>
                        <td>CENTRO</td>
                        <td><a href="#" class="btn btn-warning btn-icon-split btn-sm"
                                data-toggle="modal" data-target="#EditModal">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>

                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td>PRAT</td>
                        <td><a href="#" class="btn btn-warning btn-icon-split btn-sm"
                                data-toggle="modal" data-target="#EditModal">
                                <span class="icon text-white-50">
                                    <i class="fas fa-edit"></i>
                                </span>

                            </a>
                        </td>
                    </tr>
                </tbody>    
            </table>        
        </div>
    </div>
    <!-- /.container-fluid -->                                

</div>
<!-- End of Main Content -->
<?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/estacionamientos/controles.blade.php ENDPATH**/ ?>