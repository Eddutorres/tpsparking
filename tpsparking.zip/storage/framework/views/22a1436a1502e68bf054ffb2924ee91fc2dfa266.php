

<?php $__env->startSection('cuerpo_central'); ?>

<?php echo $__env->make('ingresos.formingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/ingresos/ingreso.blade.php ENDPATH**/ ?>