

<?php $__env->startSection('cuerpo_central'); ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Editar Cantidad de Estacionamientos</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-center" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>Sector</th>
                        <th>Numero</th>
                        <th>Editar</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $estacionamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estacionamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($estacionamiento['sector']); ?></td>
                        <td><?php echo e($estacionamiento['codigo']); ?></td>
                        <td>
                            <form action="<?php echo e(route('eliminarest')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo method_field('DELETE'); ?>                    
                                <input type="submit" class="btn btn-danger btn-icon-split btn-sm" value="ELIMINAR">
                                <input type="hidden" class="form-control" name="est_id" id="est_id" value="<?php echo e($estacionamiento['est_id']); ?>">
                                <input type="hidden" id="sector" name="sector" value="<?php echo e($estacionamiento['sector']); ?>">
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>    
            </table>


                    <div class="col-md-4">
                        <!-- Form Group (first name)-->
                        <div class="mb-2">
                            <form action="<?php echo e(route('agregarest')); ?>" method="post" >
                                <?php echo e(csrf_field()); ?>

                                <?php echo method_field('post'); ?>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Número estacionamiento" aria-label="Search" aria-describedby="basic-addon2" name="codigo" id="codigo" required>
                                    <input type="hidden" id="sector" name="sector" value="<?php echo e($estacionamiento['sector']); ?>">
                                    <div class="input-group-append">
                                        <input type="submit" class="btn btn-primary btn-icon-split btn-primary" value=" AGREGAR ">                          
                                    </div>
                                </div>
                            
                            </form>
                        </div>                
                    </div>
     
        </div>
    </div>
    <!-- /.container-fluid -->                                

</div>
<!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/estacionamientos/listar.blade.php ENDPATH**/ ?>