

<?php $__env->startSection('cuerpo_central'); ?>

<?php echo $__env->make('ingresos.controles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card shadow mb-4">

    <div class="card shadow-lg border-0 rounded-lg mt-5">
        <div class="card-header justify-content-center">
            <h3 class="fw-light my-4">Registrar Salida</h3>
        </div>
        <div class="card-body">
            <!-- Registration form-->
            <form method="POST" action="<?php echo e(route('confirmarsalida')); ?>" class="formulario-liberar">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <input type="hidden" class="form-control" name="estado_est" id="estado_est" value="0"> 
                <input type="hidden" class="form-control" name="sector" id="sector" value="<?php echo e($sector); ?>"> 
                <input type="hidden" id="fecha_reg" class="form-control" name="fecha_reg" value="<?php date_default_timezone_set("America/Santiago"); echo date("Y-m-d");?>">
                <!-- Form Row-->
                <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" class="form-control" name="id" id="id" value="<?php echo e($registro['id']); ?>">
                <div class="row gx-3">
                    <div class="col-md-6">
                        <!-- Form Group (first name)-->
                        <label for="rut">Rut</label>
                        <div class="mb-3">
                            <input class="form-control" id="rut" type="text"
                            value="<?php echo e($registro['rut']); ?>" disabled>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <!-- Form Group (last name)-->
                        <label for="patente">Patente</label>
                        <div class="mb-3">
                            <input class="form-control" id="patente" type="text"
                            value="<?php echo e($registro['patente']); ?>" disabled>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <!-- Form Group (last name)-->
                        <label for="conductor">Conductor</label>
                        <div class="mb-3">
                            <input class="form-control" id="conductor" type="text"
                            value="<?php echo e($registro['nombre1']." ".$registro['apellido1']); ?>" disabled>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <!-- Form Group (last name)-->
                        
                    </div>
                    <div class="col-md-6">
                        <!-- Form Group (last name)-->
                        <label for="hora_salida">Hora Salida</label>
                        <div class="mb-3">
                            <input class="form-control" name="hora_salida" id="hora_salida" type="time"
                            value="<?php date_default_timezone_set("America/Santiago"); echo date("H:i");?>" >
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Form Group (create account submit)-->                    
                    <input type="submit" class="btn btn-danger btn-icon-split btn-sm" value="   Liberar Estacionamiento   ">
                
                
                <a class="btn btn-secondary btn-secondary"
                    href="<?php echo e(url('/ingresos' )); ?>">Cancelar</a>
            </form>
        </div>


        <!-- Confirmar Liberar Modal-->
        <div class="modal fade" id="ConfModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Estacionamiento liberado
                            correctamente</h5>
                        <button class="close" type="button" data-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true"></span>
                        </button>
                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-primary" href="grilla_sector_varas.html">Aceptar</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('salir')=='ok'): ?>

        <script>
            Swal.fire(
            'Deleted!',
            'Your file has been Ingresado',
            'success'
            )

        </script>

    <?php endif; ?>
    <script>

        $('.formulario-liberar').submit(function(e){
            e.preventDefault();

            Swal.fire({
        title: '¿Registrar la salida?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
            'Registrado',
            'Se ha registrado la salida',
            'success'
            )
            this.submit();
            
        }
        })
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/salidas/formsalida.blade.php ENDPATH**/ ?>