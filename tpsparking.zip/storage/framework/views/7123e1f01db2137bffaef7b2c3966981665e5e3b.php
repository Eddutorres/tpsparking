

<?php $__env->startSection('cuerpo_central'); ?>

<?php echo $__env->make('reportes.controles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered text-center" id="dataTable" width="100%"
            cellspacing="0">
            <thead>
                <tr>
                    <th>Fecha de Ingreso</th>
                    <th>Hora de Ingreso</th>
                    <th>Patente</th>
                    <th>Sector</th>
                    <th>Número</th>
                    <th>Nombre Conductor</th>
                    <th>Contacto</th>
                    <th>Hora de Salida</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($reporte['fecha']); ?></td>
                    <td><?php echo e($reporte['hora_ingreso']); ?></td>
                    <td><?php echo e($reporte['patente']); ?></td>
                    <td><?php echo e($reporte['sector']); ?></td>
                    <td><?php echo e($reporte['codigo_est']); ?></td>
                    <td><?php echo e($reporte['nombre1']." ".$reporte['apellido1']); ?></td>
                    <td><?php echo e($reporte['telefono']); ?></td>
                    <td><?php echo e($reporte['hora_salida']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

    <!-- DataTales Example -->
    <div class="card-body">
        <form action="<?php echo e(route('descargar-pdf')); ?>" method="get">
                <td>
                    <input type="submit" class="btn btn-warning btn-icon-split right-align btn-sm" value="DESCARGAR REPORTE">
                </td>
                <input type="hidden" id="sector" name="sector" value="<?php echo e($sector); ?>">
                <input type="hidden" id="fecha_ini" name="fecha_ini" value="<?php echo e($fecha_ini); ?>">
                <input type="hidden" id="fecha_fin" name="fecha_fin" value="<?php echo e($fecha_fin); ?>">
        </form>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/reportes/crear.blade.php ENDPATH**/ ?>