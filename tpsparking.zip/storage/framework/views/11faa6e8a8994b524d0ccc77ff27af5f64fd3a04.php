

<?php $__env->startSection('cuerpo_central'); ?>
    
    <?php echo $__env->make('register.rut', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tema.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Duoc\Portafolio\tpsparking\resources\views/register/registro.blade.php ENDPATH**/ ?>