        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-"></i>
                </div>
                <div class="sidebar-brand-text mx-3">TPS PARKING <sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Ingresar -->
            <li class="nav-item active">
                <a class="nav-link" href="login.html">
                    <i class="fas fa-fw fa-user"></i>
                    <span>INGRESAR</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Registrar Usuario -->
            <li class="nav-item active">
                <a class="nav-link" href="register.html">
                    <i class="fas fa-fw fa-user"></i>
                    <span>REGISTRAR USUARIO</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Registrar Vehiculos -->
            <li class="nav-item active">
                <a class="nav-link" href="regV_inicio.html">
                    <i class="fas fa-fw fa-car"></i>
                    <span>REGISTRAR VEHICULOS</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Generar Reporte -->
            <li class="nav-item active">
                <a class="nav-link" href="reporte_inicio.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>GENERAR REPORTE</span></a>
            </li>


            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar --><?php /**PATH C:\xampp\htdocs\tpsparking\resources\views/main/sidebar.blade.php ENDPATH**/ ?>