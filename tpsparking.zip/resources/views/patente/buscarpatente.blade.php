@extends('tema.principal')

@section('cuerpo_central')
    
    @include('patente.buscar')
      

@endsection