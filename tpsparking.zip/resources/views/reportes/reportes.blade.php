@extends('tema.principal')

@section('cuerpo_central')

@include('reportes.controles')

@endsection