@extends('tema.principal')

@section('cuerpo_central')

@include('ingresos.controles')

@endsection