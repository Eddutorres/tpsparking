@extends('tema.principal')

@section('cuerpo_central')
    @include('tema.sectores')
      

@endsection
