@extends('tema.principal')

@section('cuerpo_central')
    

    @include('register.formingreso')


@endsection