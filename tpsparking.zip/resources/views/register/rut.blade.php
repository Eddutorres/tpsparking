@extends('tema.principal')

@section('cuerpo_central')
    
    @include('register.formrut')
@endsection